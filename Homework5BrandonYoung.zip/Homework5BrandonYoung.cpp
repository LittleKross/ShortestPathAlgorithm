#include <iostream>
#include <queue>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

class MazeNode
{
public:
    MazeNode(int ID, vector<int> neighbors) {
        known = false;
        pathCost = 1;
        id = ID;
        parent = -1;
        neighbors = neighbors;
    };
    friend ostream& operator<<(ostream& os, const MazeNode& value);
    bool known;
    int id;
    int parent;
    vector<int> neighbors;
    int pathCost;
};

ostream& operator<<(ostream& os, const MazeNode& value) {
    os << "(Node:" << value.id + 1 << ", Cost:" << value.pathCost << ", Parent:" << value.parent << ", Known:" << value.known << ", Neighbors:" << value.neighbors.size() << ")";
    return os;
}

vector<MazeNode> inputData() {
    ifstream inFile("maze.txt");
    string line;
    int value;
    vector<MazeNode> nodelist;
    while (getline(inFile, line)) {
        istringstream word(line);
        //cout << line << endl;
        word >> value;
            vector<int> neighbors;
            MazeNode node = MazeNode(value - 1, neighbors);
            while (word >> value) {
                if (value == -1) {
                    break;
                }
                node.neighbors.push_back(value - 1);
            }
            //cout << node << endl;//cout << "(" << node.id << ", " << node.known << ", " << node.parent << ", " << node.pathCost << ", " << node.neighbors.size() << ")" << endl;
            nodelist.push_back(node);
    }
    return nodelist;
}//inputData

void printVector(vector<MazeNode> data) {
    cout << "Vector:" << endl;
    for (int i = 0; i < data.size(); i++) {
        cout << data.at(i) << endl;
    }
}

void printShortestPath(vector<MazeNode> data, MazeNode current) {
    if (current.parent != -1) {
        printShortestPath(data, data.at(current.parent));
    }
    if (current.id == 99)
        cout << current;
    else
    {
        cout << current << " -> ";
    }
}

void printShortestPath(vector<MazeNode> data) {
    MazeNode current = data.at(99);
    printShortestPath(data, current);
}

vector<MazeNode> shortestPath(vector<MazeNode> data) {
    queue<MazeNode> path;
    //cout << data.front();
    path.push(data.front());
    //cout << path.front();
    //cout << !path.empty();
    while (!path.empty()) {
        MazeNode current = path.front();
        //cout << current;
        path.pop();
        //cout << "testing";
        //cout << current.neighbors.size();
        for (int i = 0; i < current.neighbors.size(); i++) {
            //cout << current.neighbors[i];
            //cout << neighbor;
            if (!data.at(current.neighbors[i]).known) {
                //cout << neighbor;
                data.at(current.neighbors[i]).pathCost = current.pathCost + 1;
                data.at(current.neighbors[i]).known = true;
                data.at(current.neighbors[i]).parent = current.id;
                //cout << data.at(current.neighbors[i]) << endl;
                path.push(data.at(current.neighbors[i]));
            }
        }

    }
    return data;
}



int main()
{
    vector<MazeNode> data = inputData();
    data = shortestPath(data);
    cout << "Shortest Path Cost: " << data.at(99).pathCost << endl << endl;
    printShortestPath(data);
    
    //printVector(data);
    //printShortestPath(data);
    
    //printShortestPath(data,data.at(data.size()-1));
    
    
    /*
    q.enqueue(v_start)

    while (!q.isEmpty()) {

        v = q.dequeue();

        for each w adjacent to v {

            if (w is unknown){

                w.cost = v.cost + 1

                w.known = true

                w.parent = v

                q.enqueue(w);

            }

        }

    }
    */

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

/*
1. 2 -1
2. 3 -1
3. 4 5 -1
4. -1
5. 6 -1
6. -1
*/

/*outputs:
Shortest Path Cost: 47


C:\Users\brandony\source\repos\Lab_5\Debug\Lab_5.exe (process 36636) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/